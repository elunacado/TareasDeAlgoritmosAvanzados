# TareasDeAlgoritmosAvanzados
Para la paz mental de Rommel
